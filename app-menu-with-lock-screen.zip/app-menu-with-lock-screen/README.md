# App Menu With Lock Screen

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/vYpXNJd](https://codepen.io/Hyperplexed/pen/vYpXNJd).

A kind of large menu inspired by the Google TV interface. Also has a lock screen component just for funsies.